package progetto;

import view.Finestra;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Finestra finestra = new Finestra();
		
		

	}

}
