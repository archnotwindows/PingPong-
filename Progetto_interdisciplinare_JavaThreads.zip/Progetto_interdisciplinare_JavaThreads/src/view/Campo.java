
package view;

import java.awt.Graphics;

import javax.swing.JPanel;

public class Campo extends JPanel {
	@Override
	public void paint(Graphics g) {
		// TODO Auto-generated method stub
		//super.paint(g);
		g.drawArc(90, 60, 30, 40, 0, 360);
		g.drawRect(10, 10, 30, 160);
		g.drawRect(870, 10, 30, 160);
 
	}
}