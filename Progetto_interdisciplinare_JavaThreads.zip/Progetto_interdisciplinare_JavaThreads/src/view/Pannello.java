package view;

import javax.swing.JPanel;

import java.awt.Graphics;

import javax.swing.JLabel;

public class Pannello extends JPanel {

	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	public Pannello() {
		setLayout(null);
 
		JLabel lbPunteggioB = new JLabel("Punteggio B");
		lbPunteggioB.setBounds(532, 24, 108, 16);
		add(lbPunteggioB);
 
		JLabel lbPunteggioA = new JLabel("Punteggio A");
		lbPunteggioA.setBounds(407, 24, 100, 16);
		add(lbPunteggioA);
 
		Campo panel = new Campo();
		panel.setBounds(46, 77, 980, 500);
		add(panel);
 
 

	}
}