/**
 * 
 */
/**
 * 
 */
module Progetto_interdisciplinare_JavaThreads {
	requires java.desktop;
}