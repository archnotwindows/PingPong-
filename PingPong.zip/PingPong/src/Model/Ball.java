package Model;


public class Ball {
	  private int x, y; // posizione della pallina
	    private int speedX, speedY; // velocità della pallina

	    public Ball() {
	        // posiziona la pallina al centro del campo da gioco
	        x = 250;
	        y = 250;
	        // imposta la velocità iniziale della pallina
	        speedX = 3;
	        speedY = 2;
	    }

	    public void move() {
	        // muove la pallina
	        x += speedX;
	        y += speedY;
	    }

	    public void checkCollisionWithPaddle(Paddle paddle1, Paddle paddle2) {
	        if (x <= 20 && y >= paddle1.getY() && y <= paddle1.getY() + 80) {
	            speedX = -speedX; // cambia direzione se colpisce la racchetta sinistra
	        } else if (x >= 460 && y >= paddle2.getY() && y <= paddle2.getY() + 80) {
	            speedX = -speedX; // cambia direzione se colpisce la racchetta destra
	        }
	    }

	    public void checkCollisionWithWall() {
	        // controlla le collisioni con i bordi del campo da gioco
	        if (y <= 0 || y >= 480) {
	            speedY = -speedY; // inverte la direzione se colpisce il soffitto o il pavimento
	        }
	        if (x <-10 || x >= 500) {
	            speedX = -speedX; // inverte la direzione se colpisce il soffitto o il pavimento
	        }
	    }

	    public int getX() {
	        return x;
	    }

	    public int getY() {
	        return y;
	    }
}
