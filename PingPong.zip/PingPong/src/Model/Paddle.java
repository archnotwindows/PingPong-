package Model;

public class Paddle {
	 private int y; // posizione del pannello
	    private final int x; // posizione fissa del pannello

	   public Paddle(int x) {
	        this.x = x;
	        // posiziona il pannello al centro del campo da gioco verticalmente
	        y = 200;
	    }

	   public void moveUp() {
	        // muove il pannello verso l'alto
	        y -= 15;
	    }

	    public void moveDown() {
	        // muove il pannello verso il basso
	        y += 15;
	    }

	    public int getX() {
	        return x;
	    }

	    public int getY() {
	        return y;
	    }
}
