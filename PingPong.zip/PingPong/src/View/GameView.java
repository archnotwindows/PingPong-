package View;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JPanel;

import Model.Ball;
import Model.Paddle;


public class GameView extends JPanel {
	  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final Ball ball;
	    private final Paddle paddle1;
	    private final Paddle paddle2;

	    public GameView(Ball ball, Paddle paddle1, Paddle paddle2) {
	        this.ball = ball;
	        this.paddle1 = paddle1;
	        this.paddle2 = paddle2;
	        setPreferredSize(new Dimension(500, 500));
	    }

	    @Override
	    public void paintComponent(Graphics g) {
	        super.paintComponent(g);
	        // disegna il campo da gioco
	        g.setColor(Color.BLACK);
	        g.fillRect(0, 0, getWidth(), getHeight());
	        // disegna la pallina
	        g.setColor(Color.WHITE);
	        g.fillOval(ball.getX(), ball.getY(), 20, 20);
	        // disegna le racchette
	        g.fillRect(paddle1.getX(), paddle1.getY(), 20, 80);
	        g.fillRect(paddle2.getX(), paddle2.getY(), 20, 80);
	    }
}
