/**
 * 
 */
/**
 * @author Studente
 *
 */
module PingPong {
	requires java.desktop;
}