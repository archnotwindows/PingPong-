package Controller;

import Model.Ball;
import Model.Paddle;
import View.GameView;

public class GameController {
	 private final Model.Ball ball;
	    private final Paddle paddle1;
	    private final Paddle paddle2;
	    private final GameView view;

	    public GameController(Ball ball, Paddle paddle1, Paddle paddle2, GameView view) {
	        this.ball = ball;
	        this.paddle1 = paddle1;
	        this.paddle2 = paddle2;
	        this.view = view;
	    }

	    public void updateGame() {
	        ball.move();
	        ball.checkCollisionWithPaddle(paddle1, paddle2);
	        ball.checkCollisionWithWall();
	        view.repaint();
	    }
}
