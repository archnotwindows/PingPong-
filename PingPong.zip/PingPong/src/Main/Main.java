package Main;

import java.awt.EventQueue;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;

import Controller.GameController;
import Model.Ball;
import Model.Paddle;
import View.GameView;



public class Main {
	  public static void main(String[] args) {
	        Ball ball = new Ball();
	        Paddle paddle1 = new Paddle(20);
	        Paddle paddle2 = new Paddle(460);
	        GameView view = new GameView(ball, paddle1, paddle2);
	        GameController controller = new GameController(ball, paddle1, paddle2, view);

	        // creazione della finestra di gioco
	        JFrame frame = new JFrame("Ping Pong");
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.getContentPane().add(view);
	        frame.pack();
	        frame.setResizable(false);
	        frame.setVisible(true);

	        // gestione dell'input utente
	        frame.addKeyListener(new KeyAdapter() {
	            @Override
	            public void keyPressed(KeyEvent e) {
	            	EventQueue.invokeLater(new Runnable() {
	            		@Override
	            		public void run() {
	            			if (e.getKeyCode() == KeyEvent.VK_W) {
	    	            		paddle1.moveUp();
	    	            	}
	    	            	
	    	            	if (e.getKeyCode() == KeyEvent.VK_S) {
	    	            		paddle1.moveDown();
	    	            	}
	            		}
	            	});
	            	
	            	EventQueue.invokeLater(new Runnable() {
	            		@Override
	            		public void run() {
	            			if (e.getKeyCode() == KeyEvent.VK_UP) {
	    	            		paddle2.moveUp();
	    	            	}
	    	            	
	    	            	if (e.getKeyCode() == KeyEvent.VK_DOWN) {
	    	            		paddle2.moveDown();
	    	            	}
	            		}
	            	});
	            	
//	                switch (e.getKeyCode()) {
//	                    case KeyEvent.VK_W:
//	                        paddle1.moveUp();
//	                        break;
//	                    case KeyEvent.VK_S:
//	                        paddle1.moveDown();
//	                        break;
//	                    case KeyEvent.VK_UP:
//	                        paddle2.moveUp();
//	                        break;
//	                    case KeyEvent.VK_DOWN:
//	                        paddle2.moveDown();
//	                        break;
//	                }
	            }
	        });

	        // loop di gioco
	        while (true) {
	            controller.updateGame();
	            try {
	                Thread.sleep(10); // rallenta il gioco per renderlo più giocabile
	            } catch (InterruptedException ex) {
	                ex.printStackTrace();
	            }
	        }
	    }
}
